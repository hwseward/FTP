## Features
- Send and Receive Files over TCP

## Installaion

- use as cargo dependencie

